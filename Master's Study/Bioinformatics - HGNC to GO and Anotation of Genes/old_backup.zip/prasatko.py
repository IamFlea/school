"""
Letadlo: Python 2.7.8 s motorem LINUX podporujici bash
Letecka Spolecnost: FIT VUTBR 

Let cislo: 42 <prasatko.sh>
Pilot: Petr Dvoracek <xdvora0n@fit.vutbr.cz>
Cas letu: 14. 11. 2014 - 16. 11. 2014


SLOVNI POPIS POSTUPU 
--------------------
Pred zacatkem letu potrebujete mit v kufru zaznam o biologickych datech chromozomu 19. 
Ten lze ziskat dvemi zpusoby.
  - Prvni je ten ze otevrete https://genome.ucsc.edu/cgi-bin/hgTables?command=start 
    Nastavte bunky na Mammal, Human, Feb 2009, Genes and gene prediction, UCSC genes, known gene
    Position napiste: chr19 a zmacknete velke tlacitko s nazvem 'lookup'
    Output format nastavte na: Selected fields from primary and related tables.
    V nasledujicich trech boxech musi byt prazdnota.
    File type returned: plain text.
    Zmacknete to nadherne tlacitko 'get output'.

    Prekresli se vam okno.
    Nejdrive v linked tables dejte fajfky na: goaPart, kgXref, hgncXref.
    Zbytek bude odskrknut, aby se vam nezobrazilo pole tabulek.
    Zmacknete tlacitko: allow section 
    Zaskrknout: 
        hg19.knownGene: name, strand, cdsStart, cdsEnd. # Potrebujeme tedy vedet zakladni info o genu.
        go.goaPart: goId (nebo gold :-) )               # Informace o go - konkretne GO:0003824 znaci katalytickou aktivitu -- yaaay enzym.
                                                        # Viz http://amigo.geneontology.org/amigo/term/GO:0003824
        hg19.kgXref: kgId                               # Specificke ID.
        proteome.hgncXref: symbol                       # HGNC symbol
    Get output.
    Tuto stranku ulozte jako 'ucsc' do adresare s timto souborem.
  - Druhy zpusob je ten, ze se kouknete do moji slozky s odevzdanymi soubory ve WISu.
    NEJDE ulozit 6 souboru :(
Spustte tento script.

Podle GO:0003824 se koukneme zda se jedna o enzym, pokud ano dojde ke zjisteni EC cisla. 
To do jake tridy patri, se zjisti podle http://geneontology.org/external2go/ec2go
kde je zakladni rozdeleni na skupiny. Nektere enzymy nemaji zakladni cislo, ale jen EC:3.4.21.

Enzymy, ktere nemaji HGNC symbol nebo nezname jejich katalytickou aktivitu dame pryc.
Co bylo zjisteno: 
     1 enzym  - oxidoreductase activity
     7 enzymu - transferase activity
    67 enzymu - hydrolase or serine-type endopeptidase activity
     0 enzymu - lyase activity
     1 enzym  - isomerase activity
    12 enzymu - ligase activity

Nasleduje tisknuti tabulek do souboru.
"""

import re 
try:
    f = open("ucsc", 'r') # [1]
except:
    print "File 'ucsc' does not exist."
    exit(1)

# Parsrovani souboru
enzymy = []
for line in f:
    line = line[:-1]
    for goId in line.split("\t")[4].split(","):
        if goId == "GO:0003824": # Je to enzym?
            #print line,
            # edit sober
            strand = line.split("\t")[1]
            start = line.split("\t")[2]
            end = line.split("\t")[3]
            hgnc = line.split("\t")[-1]
            id_ = line.split("\t")[-2]
            go = []
            ec = 0
            for item in line.split("\t")[4].split(","):
                if item == "":
                    continue
                # EC:1 > GO:oxidoreductase activity ; GO:0016491
                if item == "GO:0016491":
                    ec = 1
                # EC:2 > GO:transferase activity ; GO:0016740
                elif item == "GO:0016740":
                    ec = 2
                # EC:3 > GO:hydrolase activity ; GO:0016787
                elif item == "GO:0016787":
                    ec = 3
                # EC:3.4.21 > GO:serine-type endopeptidase activity ; GO:0004252
                elif item == "GO:0004252":
                    ec = 3
                # EC:4 > GO:lyase activity ; GO:0016829
                elif item == "GO:0016829":
                    ec = 4
                # EC:5 > GO:isomerase activity ; GO:0016853
                elif item == "GO:0016853":
                    ec = 5
                # EC:6 > GO:ligase activity ; GO:0016874
                elif item == "GO:0016874":
                    ec = 6
                go.append(item[3:])
            enzymy.append([id_, strand, start, end, ec, hgnc, go])
f.close()

# dame pryc enzymy, u kterych nezname jejich aktivitu
tmp = []
for enzym in enzymy:
    if enzym[4] != 0:
        tmp.append(enzym)
# dame pryc enzymy u kterych nezname HGNC
enzymy = []
for enzym in tmp:
    if enzym[5] != "n/a":
        enzymy.append(enzym)

# Tiskneme do formatu GFF3
color = ["", "red", "blue", "green", "white", "black", "orange"]
aktivita = ["", 
            "oxidoreductase activity", 
            "transferase activity", 
            "hydrolase activity", 
            "lyase activity", 
            "isomerase activity", 
            "ligase activity"]
nl = "\n" # new line

table = "id\tstrand\tstart coding\tend coding\thgnc\tec\taktivita enzymu" + nl
gff = ""
gff += "##gff-version 3" + nl
gff += "##sequence-region   chr19 1 59128983" + nl
for enzym in enzymy:
    gff += "chr19\t.\tgene\t"+enzym[2]+"\t"+enzym[3]+"\t.\t"+enzym[1]+"\t.\tID="+enzym[0]+"_EC:"+str(enzym[4])+nl
    table += enzym[0] + "\t" + enzym[1] + "\t" + enzym[2] + "\t" + enzym[3] + "\t" + enzym[5] + "\tEC:" +str(enzym[4]) + "\t"+aktivita[enzym[4]] + nl


f = open("table.txt", 'w')
f.write(table)
f.close()


f = open("gff3.txt", 'w')
f.write(gff)
f.close()




""" # Pokud chcete zjistit 
a=[0,0,0,0,0,0,0]
for enzym in enzymy:
    a[enzym[4]] += 1
print a
#"""




# You shall (! NOT)
pass
